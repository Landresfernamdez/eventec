﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebServiceAsistencias.Models
{
    public class PersonaUsuario
    {
        public string cedula { get; set; }
        public string nombre { get; set; }
        public string apellido1 { get; set; }
        public string apellido2 { get; set; }
        public int edad { get; set; }
        public string direccion { get; set; }
        public string correo { get; set; }
        public string contrasena { get; set; }
     
    }
}
