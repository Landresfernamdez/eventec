

angular.module('userModule')
.controller('miperfilController', function ($scope, OperationsProfile) {
    $scope.usuario = {
        cedula: "",
        correo: "",
        password: ""

    };

    $scope.perfil = OperationsProfile.getProfile(function (res) {
        $scope.datos = res;
        console.log($scope.datos);
    });






});
