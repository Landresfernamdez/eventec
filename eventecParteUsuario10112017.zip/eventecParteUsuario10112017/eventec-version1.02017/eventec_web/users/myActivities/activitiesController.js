angular.module('userModule')
    .controller('activitiesController', function ($scope, $http,$window,$location, OperationsActividades) {
        console.log("entro");

        var user =  sessionStorage.getItem("session.user");

        $scope.usuarioActividad = {

            idUsuario: sessionStorage.getItem("session.user"),
            idActividad: "",
            nombre: "",
            descripcion:  "",
            fecha: "",
            cupo: "",
            lugar: "",
            horaInicio: "",
            horaFinal: "",
            duracion: ""

        };
        //Carga los datos al model editar
        $scope.cargarModal = function (actividad) {
            $scope.usuarioActividad.nombre= actividad.nombre;
            $scope.usuarioActividad.descripcion = actividad.descripcion;
            $scope.usuarioActividad.lugar = actividad.lugar;
            $scope.usuarioActividad.horaInicio = actividad.horaInicio;
            $scope.usuarioActividad.horaFinal = actividad.horaFinal;
            $scope.usuarioActividad.fecha = actividad.fecha;
            $scope.usuarioActividad.cupo = actividad.cupo;
            $scope.usuarioActividad.duracion = actividad.duracion;
        };

        $scope.getlista = OperationsActividades.getActividadesInscritos(function (res){
            console.log(res);
            $scope.lista  = res;
            console.log($scope.lista);
        });

        $scope.reload = function() {
            $window.location.reload();
        };

        $scope.eliminarActividad = function (actividad) {

            actividad.idUsuario = user;
            OperationsActividades.eliminarActividad(actividad, function (response) {
                if (response.success) {
                }

            });
        };

    });