angular.module('userModule')
    .controller('activitiesController', function ($scope, $http,$window,$location, OperationsActividades) {
        console.log("entro");

        $scope.usuarioActividad = {

            nombreEvento: "",
            idUsuario: sessionStorage.getItem("usuario"),
            idActividad: "",
            nombre: "",
            descripcion:  "",
            fecha: "",
            cupo: "",
            lugar: "",
            horaInicio: "",
            horaFinal: "",
            duracion: ""

        };

        $scope.getlista = OperationsActividades.getActividadesInscritos(function (res){
            console.log(res);
            $scope.lista  = res;

        });

        $scope.reload = function() {
            $window.location.reload();
        };

        $scope.eliminarActividad = function (actividad) {

            actividad.idUsuario = sessionStorage.getItem("usuario");
            OperationsActividades.eliminarActividad(actividad, function (response) {
                if (response.success) {
                }

            });
        };

    });