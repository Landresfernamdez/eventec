var app = angular.module('userModule');
app.controller('eventosController', function ($scope, $route, $window, $location, OperationsEventos) {

    console.log("entro");


    $scope.evento = {
        idEvento: "",
        nombre: "",
        descripcion: "",
        fechaInicio: "",
        fechaFinal: ""
    };

    $scope.eventoActividad = {

        idActividad: "",
        nombre: "",
        descripcion: "",
        fecha: "",
        cupo: "",
        lugar: "",
        horaInicio: "",
        horaFinal: "",
        duracion: ""

    };

    $scope.usuario = {
        cedula: "",
        nombre: "",
        apellido1: "",
        apellido2: "",
        edad: 0,
        direccion: "",
        correo: "",
        contrasena: ""

    };

    $scope.usuarioActividad = {

        idUsuario: sessionStorage.getItem("session.user"),
        idActividad: "",
        nombre: "",
        descripcion: "",
        fecha: "",
        cupo: "",
        lugar: "",
        horaInicio: "",
        horaFinal: "",
        duracion: ""

    };

    $scope.view = {
        name: ''

    };

    $scope.reload = function () {
        $window.location.reload();
    };
    //Carga los datos al model editar
    $scope.cargarModal = function (evento) {
        $scope.evento.idEvento = evento.idEvento;
        $scope.evento.nombre = evento.nombre;
        $scope.evento.descripcion = evento.descripcion;
        $scope.evento.fechaInicio = evento.fechaInicio.substr(0, 10);
        $scope.evento.fechaFinal = evento.fechaFinal.substr(0, 10);

    };
    $scope.getlistaEventos = OperationsEventos.getEvento(function (res) {
        console.log(res);
        $scope.listaEventos = res;
        console.log($scope.listaEventos);
    });


    //Carga los datos para crear los usuarios y se registren
    $scope.crearUsuario = function (usuario, pass2) {

        if (usuario.contrasena === pass2) {
            OperationsEventos.insertUsuario(usuario, function (res) {
                if (res) {

                    $window.location.href = ('http://localhost:63342/eventec_web/index.html');
                    $scope.listaUsuarios = res;
                }
            });
        } else {
            swal({
                title: 'Los datos no estan completos o mal editados...',
                type: 'warning',
                showConfirmButton: false,
                timer: 2000
            });
        }

    };

    var user = sessionStorage.getItem("session.user");

    $scope.enlazarUsuarioActividad = function (actividad) {

        $scope.usuarioActividad.idUsuario = user;
        $scope.usuarioActividad.idActividad = actividad.idActividad;
        $scope.usuarioActividad.nombre = actividad.nombre;
        $scope.usuarioActividad.descripcion = actividad.descripcion;
        $scope.usuarioActividad.lugar = actividad.lugar;
        $scope.usuarioActividad.fecha = actividad.fecha;
        $scope.usuarioActividad.horaInicio = actividad.horaInicio;
        $scope.usuarioActividad.horaFinal = actividad.horaFinal;
        $scope.usuarioActividad.cupo = actividad.cupo;
        $scope.usuarioActividad.duracion = actividad.duracion;

        console.log($scope.usuarioActividad);

        OperationsEventos.enlazarActividad($scope.usuarioActividad, function (res) {

            if ($scope.usuarioActividad.cupo === 0) {
                swal({
                    title: 'Ya no hay cupo para la actividad!',
                    type: 'info',
                    showConfirmButton: false,
                    timer: 2000
                });
            }
            if (res) {
                console.log(res);
            }
        });
    };

    $scope.obtenerActividades = function (evento) {
        OperationsEventos.getActividadesEvento(evento, function (res) {
            if (res) {
                OperationsEventos.getEventoActividades(function (res) {
                    console.log(res);
                    $scope.listaActividades = res;
                });
            }
        });

    };

    $scope.getItemUser = function () {
        $scope.idUser = sessionStorage.getItem("session.user");
        return $scope.idUser;
    };
});

