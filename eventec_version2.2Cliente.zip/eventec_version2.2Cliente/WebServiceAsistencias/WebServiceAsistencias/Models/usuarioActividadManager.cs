﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Data.SqlClient;


namespace WebServiceAsistencias.Models
{
    public class usuarioActividadManager
    {
        public string cadenaConexion = RouteConfig.cadenaConexion;

        public bool usuarioConActividad(UsuarioActividad usuarioAct)
        {
            SqlConnection con = new SqlConnection(cadenaConexion);
            con.Open();
            
            string sql = "EXEC inscribirUsuario @cedula, @idActividad";

            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.Add("@cedula", System.Data.SqlDbType.NVarChar).Value = usuarioAct.idUsuario;
            cmd.Parameters.Add("@idActividad", System.Data.SqlDbType.NVarChar).Value = usuarioAct.idActividad;

            int res = cmd.ExecuteNonQuery();
            
            con.Close();

            return (res == 1);

        }

        public List<Actividad> getInformacionaActividadesUsuario(string idUser)
        {
      
            List<Actividad> lista = new List<Actividad>();

            SqlConnection con = new SqlConnection(cadenaConexion);
            con.Open();

            string sql = "EXEC usuarioActividades @idUser";

            SqlCommand cmd  = new SqlCommand(sql, con);

            cmd.Parameters.Add("@idUser", System.Data.SqlDbType.NVarChar).Value = idUser;  
            
            SqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

            while (reader.Read())
            {
                Actividad  act = new Actividad();
                act.nombreEvento = reader.GetString(0);
                act.idActividad = reader.GetString(1);
                act.nombre = reader.GetString(2);
                act.lugar = reader.GetString(3);
                act.horaInicio = reader.GetTimeSpan(4).ToString();
                act.horaFinal = reader.GetTimeSpan(5).ToString();
                act.descripcion = reader.GetString(6);
                act.fecha = reader.GetDateTime(7).Date.ToString();
                act.cupo = reader.GetInt32(8);
                act.duracion = reader.GetTimeSpan(9).ToString();

                lista.Add(act);

            }
            reader.Close();

            return lista;
        }

        public bool eliminarActividad(UsuarioActividad act)
        {
            SqlConnection con = new SqlConnection(cadenaConexion);
            con.Open();
            string sql = "EXEC eliminarActividad @cedula,@idActividad";
            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.Add("@cedula", System.Data.SqlDbType.NVarChar).Value = act.idUsuario;
            cmd.Parameters.Add("@idActividad", System.Data.SqlDbType.NVarChar).Value = act.idActividad;

            int res = cmd.ExecuteNonQuery();

            con.Close();

            return (res == 1);
        }
    }
}
