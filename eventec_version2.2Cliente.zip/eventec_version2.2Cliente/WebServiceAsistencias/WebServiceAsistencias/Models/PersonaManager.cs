﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Text;
namespace WebServiceAsistencias.Models
{
    public class PersonaManager
    {
        public string cadenaConexion = RouteConfig.cadenaConexion;

        public Usuario ObtenerUsuario(byte[] ida, byte[] pass)
        {
            Usuario user = null;

            SqlConnection con = new SqlConnection(cadenaConexion);

            con.Open();

            string sql = "SELECT u.cedula, u.correo, u.contraseña, u.tipoCuenta FROM Usuarios as u WHERE u.cedula = @cedula and u.contraseña=@pass";

            String b64 = HttpServerUtility.UrlTokenEncode(ida);
            String id2 = Encoding.UTF8.GetString(HttpServerUtility.UrlTokenDecode(b64));
            String b641 = HttpServerUtility.UrlTokenEncode(pass);
            String pass2 = Encoding.UTF8.GetString(HttpServerUtility.UrlTokenDecode(b641));

            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.Add("@cedula", System.Data.SqlDbType.NVarChar).Value = id2;
            cmd.Parameters.Add("@pass", System.Data.SqlDbType.NVarChar).Value = pass2;

            SqlDataReader reader =
                cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

            if (reader.Read())
            {
                user = new Usuario();
                user.cedula = reader.GetString(0);            
                user.correo = reader.GetString(1);
                user.contrasena = reader.GetString(2);
                user.tipoCuenta = reader.GetString(3);
                user.success = false;
            }
            reader.Close();
            if (user != null)
            {
                if (user.contrasena.Equals(pass) || user.tipoCuenta.Equals("u"))
                {
                    user.success = true;
                    user.token = "Pame2015";
                    return user;
                }
            }

            user = new Usuario();
            user.success = false;
            user.cedula = reader.GetString(0);
            user.correo = reader.GetString(1);
            user.contrasena = reader.GetString(2);
            user.tipoCuenta = reader.GetString(3);

            return user;
        }

        public List<Usuario> getUsuarios()
        {
            List<Usuario> users = new List<Usuario>();

            SqlConnection con = new SqlConnection(cadenaConexion);

            con.Open();

            string sql = "select * from Usuarios";

            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataReader reader =
                cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

            while (reader.Read())
            {
                Usuario u = new Usuario();
                u.cedula = reader.GetString(0);
                u.correo = reader.GetString(1);
                try
                {
                    u.correo = reader.GetString(1);
                }
                catch (Exception e)
                {
                    u.correo = e.Message;
                }
                u.contrasena = reader.GetString(2);
                u.tipoCuenta = reader.GetString(3);
                users.Add(u);
            }

            reader.Close();
            return users;
        }
        public bool ActualizarEstudiante(Persona persona)
        {
            SqlConnection con = new SqlConnection(cadenaConexion);

            con.Open();

            string sql = "UPDATE Persona SET estado=@estado WHERE cedula=@cedula";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.Add("@estado", System.Data.SqlDbType.NVarChar).Value = persona.estado;
            cmd.Parameters.Add("@cedula", System.Data.SqlDbType.NVarChar).Value = persona.cedula;
            
            int res = cmd.ExecuteNonQuery();

            con.Close();

            return (res == 1);
        }

        public bool insertarPersonaUsuario(PersonaUsuario user)
        {
            
            SqlConnection con = new SqlConnection(cadenaConexion);

            con.Open();

            string sql = "EXEC agregarUsuario @ced,@nombre,@ap1,@ap2,@edad,@direc,@correo,@pass";

            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.Add("@ced", System.Data.SqlDbType.NVarChar).Value = user.cedula;
            cmd.Parameters.Add("@nombre", System.Data.SqlDbType.NVarChar).Value = user.nombre;
            cmd.Parameters.Add("@ap1", System.Data.SqlDbType.NVarChar).Value = user.apellido1;
            cmd.Parameters.Add("@ap2", System.Data.SqlDbType.NVarChar).Value = user.apellido2;
            cmd.Parameters.Add("@edad", System.Data.SqlDbType.NVarChar).Value = user.edad; 
            cmd.Parameters.Add("@direc", System.Data.SqlDbType.NVarChar).Value = user.direccion;
            cmd.Parameters.Add("@correo", System.Data.SqlDbType.NVarChar).Value = user.correo;
            cmd.Parameters.Add("@pass", System.Data.SqlDbType.NVarChar).Value = user.contrasena;
         
            int res = cmd.ExecuteNonQuery();

            con.Close();

            return (res == 1);
        }

    }
    
}