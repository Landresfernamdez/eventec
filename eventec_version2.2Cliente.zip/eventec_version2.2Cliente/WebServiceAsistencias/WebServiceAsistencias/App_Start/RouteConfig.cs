﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace WebServiceAsistencias
{
    public class RouteConfig
    {

        //86374844botas
        //192.168.1.5
        public static string cadenaConexion = @"Data Source=localhost;Initial Catalog=EvenTEC;User Id=sa;Password=1234";
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "AccesoActividad",
                "Actividades/Actividad/{ida}",
                new
                {
                    controller = "Actividades",
                    action = "Evento",
                    id = UrlParameter.Optional
                }
                );
            routes.MapRoute(
                 "AccesoPersonas",
                 "Personas",
                 new
                 {
                     controller = "Edecanes",
                     action = "Edecanes"
                 }
                 );
            routes.MapRoute(
                "AccesoActivity",
                "Activities",
                new
                {
                    controller = "Activities",
                    action = "Activity"
                }
                );
            routes.MapRoute(
                "AccesoActivities",
                "Activities/Activity/{id}",
                new
                {
                    controller = "Activities",
                    action = "Activity",
                    id = UrlParameter.Optional
                }
                );
            routes.MapRoute(
                 "AccesoActivityUpdate",
                 "ActivitiesUpdate",
                 new
                 {
                     controller = "Activities",
                     action = "ActivityUpdate"
                 }
                 );
            routes.MapRoute(
                "AccesoActivitys",
                "ActivitiesDelete",
                new
                {
                    controller = "Activities",
                    action = "ActivityDelete"
                }
                );
          
            routes.MapRoute(
                "AccesoRegistros",//Cambie de Registro a Registros
                "Registros",
                    new
                    {
                        controller = "Registros",
                        action = "Registros",
                        place = UrlParameter.Optional
                    }
                );
            routes.MapRoute(
                "AccesoRegisters",
                "Registers",
                    new
                    {
                        controller = "Registers",
                        action = "Registers",
                        place = UrlParameter.Optional
                    }
                );
            routes.MapRoute(
                "AccesoEventos",
                "Eventos/Evento/{id}",
                new
                {
                    controller = "Eventos",
                    action = "Evento",
                    id = UrlParameter.Optional,
                    pass = UrlParameter.Optional
                }
                );
            routes.MapRoute(
                 "AccesoEventosAdministradores",
                 "Eventos",
                 new
                 {
                     controller = "Eventos",
                     action = "EventosAdministradores"
                 }
                 );
            routes.MapRoute(
                  "AccesoEventosAdministradoresUpdate",
                  "EventosUpdate",
                  new
                  {
                      controller = "Eventos",
                      action = "EventosUpdate"
                  }
                  );
            routes.MapRoute(
                   "AccesoEventosAdministradoresAdd",
                   "EventosAdd",
                   new
                   {
                       controller = "Eventos",
                       action = "EventosAdd"
                   }
                   );
            routes.MapRoute(
                        "AccesoEdecanes",
                        "Edecanes/Edecan/{id}/{pass}",
                        new
                        {
                            controller = "Edecanes",
                            action = "Edecan",
                            id = UrlParameter.Optional,
                            pass = UrlParameter.Optional

                        }
                        );
            routes.MapRoute(
                        "AccesoAdministradores",
                        "Administradores/Administrador/{ida}/{pass}",
                        new
                        {
                            controller = "Administradores",
                            action = "Administrador",
                            id = UrlParameter.Optional,
                            pass = UrlParameter.Optional
                        }
                        );
            routes.MapRoute(
                    "AccesoUsuariosLogin",
                    "Personas/Usuario/{ida}/{pass}",
                    new
                    {
                        controller = "Personas",
                        action = "Usuario",
                        id = UrlParameter.Optional,
                        pass = UrlParameter.Optional
                    }
                    );
            routes.MapRoute(
                            "AccesoPersona",
                            "Personas/Persona/{id}",
                            new
                            {
                                controller = "Personas",
                                action = "Persona",
                                id = UrlParameter.Optional
                            }
                            );

            routes.MapRoute(
                           "AccesoUsuarios",
                           "Usuarios",
                           new
                           {
                               controller = "Personas",
                               action = "getUsuarios",

                           }
                           );
            routes.MapRoute(
                          "AccesoPersonasU",
                          "Personas",
                          new
                          {
                              controller = "Personas",
                              action = "Persona"
                          });

            routes.MapRoute(
                           "AccesoUsuariosAdd",
                           "UsuariosAdd",
                           new
                           {
                               controller = "Personas",
                               action = "usuarioAgregar"
                           });

        
            routes.MapRoute(
                          "AccesoUsuarioActividad",
                          "usuarioConActividad",
                          new
                          {
                              controller = "UsuarioActividad",
                              action = "usuarioActividad"
                          });
            routes.MapRoute(
                          "AccesoEventoActividades",
                          "Eventos/Actividades/{id}/{user}",
                          new
                          {
                              controller = "Actividades",
                              action = "EventoActividades",
                              id = UrlParameter.Optional,
                              user = UrlParameter.Optional

                          });
        
            routes.MapRoute(
                       "AccesoActividadesUsuario",
                       "actividadesUsuario/{idUser}",
                       new
                       {
                           controller = "UsuarioActividad",
                           action = "getActividadesUsuario",
                           idUser = UrlParameter.Optional
                       });

            routes.MapRoute(
                      "AccesoEliminarActividadesU",
                      "eliminarActividad",
                      new
                      {
                          controller = "UsuarioActividad",
                          action = "eliminarAct"     
                      });


            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}/{pass}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional, pass = UrlParameter.Optional, place = UrlParameter.Optional }
            );
        }
    }
}