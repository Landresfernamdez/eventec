﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebServiceAsistencias.Models
{
    public class Registro
    {
        public string idActividad { get; set; }
        public string cedula { get; set; }
        public string fecha { get; set; }
        public string hora { get; set;}
    }
}