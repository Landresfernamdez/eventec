angular.module('loginModule', ['ngRoute', 'ngResource'])
    .controller('loginController', function ($scope, $window, $http, $location, $route) {

    // modelo de datos.
    $scope.ida = "";
    $scope.pass = "";

    var ip = "http://localhost";

    var user = {
        id: null,
        nombre: null
    };

    /**
     * Ejecuta el inicio de sesión.o
     */
    $scope.usuario = {

        cedula: "",
        nombre: "",
        apellido1: "",
        apellido2: "",
        edad: 0,
        direccion: "",
        correo: "",
        contrasena: ""

    };

    /// METODO que ingresa como invitado
    $scope.doLoginA = function () {
        $scope.usuario.cedula = "";
        user.id = $scope.usuario.cedula;

        saveSession(user);
        $window.location.href = 'users/MainViewInvitado.html';

    };

    //metodo que me permite ingresar al sistema, con la condicion que ya exista el usuario
    $scope.doLoginU = function (usuario) {

        user.id = $scope.usuario.cedula;

        saveSessionU(user);

        console.log(ida);
        console.log(pass);

        var ida = Base64.encode($scope.usuario.cedula);
        var pass = Base64.encode($scope.usuario.contrasena);

        console.log(ida);
        console.log(pass);

        $http({
            method: "GET",
            url: ip + "/Personas/Usuario?ida=" + ida + "&pass=" + pass

        }).then(function mySuccess(response) {

            var estado = response.data;
            if (estado) {

                alert("Bienvenido " + $scope.usuario.cedula);
                saveSessionU($scope.usuario);
                window.location.href = 'users/MainView.html';

            }
            else {
                alert("Credenciales incorrectas");
                console.log("Credenciales incorrectas");
            }

        });
    };


    //se hace el metodo para registrar el usuario
    $scope.registrarUsuario = function (usuario, pass2) {

        //se valida que ambas contraseñas sean iguales
        if (usuario.contrasena === pass2) {

            console.log($scope.usuario);

            $http({

                method: "POST",
                url: ip + "/UsuariosAdd",
                data: usuario

            }).success(function (data) {

                swal({
                        title: 'Has sido registrado!',
                        type: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });

            });

        } else {
            swal({
                title: 'Los datos no estan completos o mal editados...',
                type: 'warning',
                showConfirmButton: false,
                timer: 2000
            });

        }


    };
    /**
     * Guarda la sesión en el almacenamiento local del navegador.
     * @param json JSON de origen.
     */
    function saveSessionU(json) {
        sessionStorage.setItem("session.user", json.cedula);
        console.log("Sesión guardada");
    }

    function saveSession(json) {
        sessionStorage.setItem("session.user", json.cedula);
        console.log("Invitado");
    }
});


