angular.module('userModule',['ngRoute'])
.config(['$routeProvider',function($routeProvider)
    {
        $routeProvider
                    .when("/",{
                        templateUrl:'index.html',
                        controller: 'loginController'
                    })
                    .when("/myActivities",{
                        templateUrl:'myActivities/myActivities.html',
                        controller: 'activitiesController'
                                             })
                    .when("/eventos",{
                        templateUrl:'eventos/eventos.html',
                        controller: 'eventosController'
                    })

                    .when("/eventosI",{
                        templateUrl:'eventos/eventosInvitado.html',
                        controller: 'eventosController'
                    })



    }
]);