﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebServiceAsistencias.Models;

namespace WebServiceAsistencias.Controllers
{
    public class PersonasController:Controller
    {
        private PersonaManager personasManager;

        public PersonasController()
        {
            personasManager = new PersonaManager();
        }

        // GET /Api/Clientes
        // POST    Clientes/Lugar    { Nombre:"nombre", Telefono:123456789 }
        // PUT     Clientes/Lugar/3  { Id:3, Nombre:"nombre", Telefono:123456789 }
        // GET     Clientes/Lugar/3
        // DELETE  Clientes/Lugar/3

        public JsonResult Usuario(byte[] ida, byte[] pass)
        {
            switch (Request.HttpMethod)
            {
                case "GET":
                    return Json(personasManager.ObtenerUsuario(ida,pass),
                                JsonRequestBehavior.AllowGet);
            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });
        }

        public JsonResult getUsuarios(string id)
        {
            switch (Request.HttpMethod)
            {
                case "GET":
                    return Json(personasManager.getUsuarios(),
                                JsonRequestBehavior.AllowGet);
            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });
        }

        public JsonResult usuarioAgregar(PersonaUsuario user)
        {
            switch (Request.HttpMethod)
            {

                case "POST":

                    return Json(personasManager.insertarPersonaUsuario(user));

            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });
        }

    }
}