﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebServiceAsistencias.Models;

namespace WebServiceAsistencias.Controllers
{
    public class UsuarioActividadController : Controller
    {

        private usuarioActividadManager userActividad;

        public UsuarioActividadController()
        {
            userActividad= new usuarioActividadManager();
        }

        public JsonResult usuarioActividad(UsuarioActividad u)
        {

            switch (Request.HttpMethod)
            {

                case "POST":
                    return Json(userActividad.usuarioConActividad(u));

            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });

        }


        public JsonResult getActividadesUsuario(string idUser)
        {

            switch (Request.HttpMethod)
            {

                case "GET":
                    return Json(userActividad.getInformacionaActividadesUsuario(idUser), JsonRequestBehavior.AllowGet);

            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });

        }

        public JsonResult eliminarAct(UsuarioActividad u)
        {

            switch (Request.HttpMethod)
            {

                case "POST":
                    return Json(userActividad.eliminarActividad(u));

            }

            return Json(new { Error = true, Message = "Operación HTTP desconocida" });

        }
    }
}
